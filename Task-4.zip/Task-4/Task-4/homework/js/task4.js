// function calculateProfit() {
    var initialAmount = parseFloat(prompt("Enter amount:"));
    var numberOfYears = parseInt(prompt("Enter the number of years:"));
    var percentageOfYear = parseFloat(prompt("Enter percentage of the year:"));
    if (isNaN(initialAmount) || initialAmount < 1000 || isNaN(numberOfYears) || numberOfYears < 1 || isNaN(percentageOfYear) || percentageOfYear > 100) {
        alert("Invalid input data");
      } else {
        var totalProfit = 0;
        var totalAmount = initialAmount;
        var result = "";
        for (var i = 1; i <= numberOfYears; i++) {
          var profit = totalAmount * (percentageOfYear / 100);
          totalProfit += profit;
          totalAmount += profit;
          result += "<br>"+i + " Year<br>Total profit: " + profit.toFixed(2) + "<br>Total amount: " + totalAmount.toFixed(2) + "<br><br>";
        }
        document.write("Initial amount: " + initialAmount.toFixed(2) + 
              "<br>Number of years: " + numberOfYears + 
              "<br>Percentage of year: " + percentageOfYear.toFixed(2) + 
              "<br><br>" + result +
              "<br>Total profit: " + totalProfit.toFixed(2) + 
              "<br>Total amount: " + totalAmount.toFixed(2));
      }
    // }
    